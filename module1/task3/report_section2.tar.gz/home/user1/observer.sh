#!/bin/bash

CONF_FILE="observer.conf"
LOG_FILE="observer.log"

if [ ! -f "$CONF_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') Конфигурационный файл $CONF_FILE не найден" >> "$LOG_FILE"
    exit 1
fi

while IFS= read -r script_path || [ -n "$script_path" ]; do
    [ -z "$script_path" ] && continue
    script_name=$(basename "$script_path")
    is_running=0
    for p in /proc/[0-9]*; do
        if [ -d "$p" ] && grep -q "$script_name" "$p/cmdline" 2>/dev/null; then
            is_running=1
            break
        fi
    done
    if [ $is_running -eq 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск $script_path" >> "$LOG_FILE"
        nohup "$script_path" > /dev/null 2>&1 &
    fi
done < "$CONF_FILE"
