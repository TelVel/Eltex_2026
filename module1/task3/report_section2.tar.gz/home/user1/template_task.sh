#!/bin/bash

SCRIPT_NAME=$(basename "$0")
PID=$$

if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

LOG_FILE="$HOME/report_${SCRIPT_NAME}.log"
PIPE_PATH="/tmp/cuckoo.pipe"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт запущен" >> "$LOG_FILE"

CUCKOO_PID=""
for p in /proc/[0-9]*; do
    if grep -q "cuckoo.sh" "$p/cmdline" 2>/dev/null; then
        CUCKOO_PID=$(basename "$p")
        break
    fi
done

if [ -n "$CUCKOO_PID" ]; then
    REQ_MSG="$SCRIPT_NAME[$PID]: how much time do I have?"
    if timeout 3 bash -c "echo '$REQ_MSG' > '$PIPE_PATH'"; then
        if read -t 5 N < "$PIPE_PATH"; then
            if [[ "$N" =~ ^[0-9]+$ ]]; then
                sleep "$N"
                echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
            else
                echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Ошибка: неверный ответ от cuckoo ($N)" >> "$LOG_FILE"
            fi
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Ошибка: таймаут ожидания ответа" >> "$LOG_FILE"
        fi
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Ошибка: cuckoo не отвечает (таймаут записи)" >> "$LOG_FILE"
    fi
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Ошибка: cuckoo.sh не запущен" >> "$LOG_FILE"
fi
