#!/bin/bash

PIPE_PATH=""
for arg in "$@"; do
    if [[ $arg == --pishitesuda=* ]]; then
        PIPE_PATH="${arg#*=}"
    fi
done

if [ -z "$PIPE_PATH" ]; then
    echo "Ошибка: не указан путь к каналу"
    exit 1
fi

LOG_FILE="$HOME/cuckoo.log"

rm -f "$PIPE_PATH"
mkfifo "$PIPE_PATH"

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG_FILE"

trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> "$LOG_FILE"; rm -f "$PIPE_PATH"; exit 0' SIGTERM SIGINT

while true; do
    if read -r line < "$PIPE_PATH"; then
        if [[ "$line" =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            N=$(( (RANDOM % 9) + 2 ))
            echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME[$PID] $N" >> "$LOG_FILE"
            echo "$N" > "$PIPE_PATH"
        fi
    fi
done
